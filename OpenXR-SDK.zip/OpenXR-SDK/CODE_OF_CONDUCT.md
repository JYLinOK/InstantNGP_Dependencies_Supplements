
<!--
Copyright (c) 2014-2022, The Khronos Group Inc.

SPDX-License-Identifier: CC-BY-4.0
-->

A reminder that this issue tracker is managed by the Khronos Group.
Interactions here should follow the Khronos Code of Conduct
([https://www.khronos.org/developers/code-of-conduct](https://www.khronos.org/developers/code-of-conduct)),
which prohibits aggressive or derogatory language.
Please keep the discussion friendly and civil.
